package kg.ksucta.ead.rent.demo.model;

import javax.persistence.*;

@Entity
@Table(name = "customers")
public class Customers {
    @Id
    @GeneratedValue
    private int CustomersID;
    @Column
    private String RrvLicNumber;
    @Column
    private String FullName;
    @Column
    private String Address;
    @Column
    private String Country;
    @Column
    private String City;

    public Customers(){

    }
    public int getCustomersID() {
        return CustomersID;
    }

    public void setCustomersID(int customersID) {
        CustomersID = customersID;
    }

    public String getRrvLicNumber() {
        return RrvLicNumber;
    }

    public void setRrvLicNumber(String rrvLicNumber) {
        RrvLicNumber = rrvLicNumber;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }
}
