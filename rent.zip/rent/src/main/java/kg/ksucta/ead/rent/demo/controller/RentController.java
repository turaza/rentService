package kg.ksucta.ead.rent.demo.controller;

import kg.ksucta.ead.rent.demo.model.Cars;
import kg.ksucta.ead.rent.demo.model.Customers;
import kg.ksucta.ead.rent.demo.model.Employees;
import kg.ksucta.ead.rent.demo.model.RentalOrders;
import kg.ksucta.ead.rent.demo.repositories.CarsRepository;
import kg.ksucta.ead.rent.demo.repositories.CustomersRepository;
import kg.ksucta.ead.rent.demo.repositories.EmployeesRepository;
import kg.ksucta.ead.rent.demo.repositories.RentalOrdersRepository;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/")
public class RentController {
    @Autowired
    private CarsRepository carsRepository;
    @Autowired
    private CustomersRepository customersRepository;
    @Autowired
    private EmployeesRepository employeesRepository;
    @Autowired
    private RentalOrdersRepository rentalOrdersRepository;

    private List<Cars> cars = new ArrayList<>();
    private List<Customers> customers = new ArrayList<>();
    private List<Employees> employees = new ArrayList<>();
    private List<RentalOrders> rentalOrders = new ArrayList<>();


    @RequestMapping(path = "/cars", method = RequestMethod.GET)
    @ResponseBody
    public List<Cars> getCars(){
        cars = carsRepository.findAll();
        return cars;
    }
    @RequestMapping(path = "/customers", method = RequestMethod.GET)
    @ResponseBody
    public List<Customers> getCustomers(){
        customers = customersRepository.findAll();
        return customers;
    }
    @RequestMapping(path = "/employees", method = RequestMethod.GET)
    @ResponseBody
    public List<Employees> getEmployees(){
        employees = employeesRepository.findAll();
        return employees;
    }
    @RequestMapping(path = "/rentalOrders", method = RequestMethod.GET)
    @ResponseBody
    public Iterable<RentalOrders> getRentalOrders(){
        rentalOrders = rentalOrdersRepository.findAll();
        return rentalOrders;
    }
    @CrossOrigin(origins = "*")
    @RequestMapping(path = "/createcars", method = RequestMethod.POST)
    @ResponseBody
    public Iterable<Cars> postCars(@RequestBody Cars car){
        carsRepository.save(car);
        return carsRepository.findAll();
    }
    @CrossOrigin(origins = "*")
    @RequestMapping(path = "/createcustomers", method = RequestMethod.POST)
    @ResponseBody
    public Iterable<Customers> postCustomer(@RequestBody Customers cust){
        customersRepository.save(cust);
        return customersRepository.findAll();
    }
    @CrossOrigin(origins = "*")
    @RequestMapping(path = "/createemployees", method = RequestMethod.POST)
    @ResponseBody
    public Iterable<Employees> postEmployees(@RequestBody Employees Empl){
        employeesRepository.save(Empl);
        return employeesRepository.findAll();
    }
    @CrossOrigin(origins = "*")
    @RequestMapping(path = "/createrent", method = RequestMethod.POST)
    @ResponseBody
    public Iterable<RentalOrders> postRentalOrders(@RequestBody RentalOrders rent){
        rentalOrdersRepository.save(rent);
        return rentalOrdersRepository.findAll();
    }

    @RequestMapping(path = "/{carID}", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseEntity<Cars> delete(@PathVariable(name = "carID", value = "carID") Integer carID){
        carsRepository.delete(carID);
        return new ResponseEntity("success", HttpStatus.OK);
    }
    @RequestMapping(path = "/{employeeID}", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseEntity<Employees> deleteEmpl(@PathVariable(name = "employeeID", value = "employeeID") Integer employeeID){
        employeesRepository.delete(employeeID);
        return new ResponseEntity("success", HttpStatus.OK);
    }
    @RequestMapping(path = "/{customersID}", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseEntity<Customers> deleteCust(@PathVariable(name = "customersID", value = "customersID") Integer customersID){
        customersRepository.delete(customersID);
        return new ResponseEntity("success", HttpStatus.OK);
    }
    @RequestMapping(path = "/{rentalOrderID}", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseEntity<RentalOrders> deleteRent(@PathVariable(name = "rentalOrderID", value = "rentalOrderID") Integer rentalOrderID){
        rentalOrdersRepository.delete(rentalOrderID);
        return new ResponseEntity("success", HttpStatus.OK);
    }


    @RequestMapping(path = "/{carID}", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity<Cars> updateCar(@PathVariable(name = "carID", value = "carID") Integer carID, @RequestBody Cars car){
        Cars currentCar = carsRepository.findOne(carID);
        if (currentCar == null){
            return ResponseEntity.notFound().build();
        }
        currentCar.setModel(car.getModel());
        currentCar.setMake(car.getMake());
        currentCar.setTagNumber(car.getTagNumber());
        carsRepository.save(currentCar);
        return new ResponseEntity(currentCar, HttpStatus.OK);
    }

    @RequestMapping(path = "/{employeesID}", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity<Cars> updateCar(@PathVariable(name = "employeesID", value = "employeesID") Integer employeesID, @RequestBody Employees employees){
        Employees currentEmp = employeesRepository.findOne(employeesID);
        if (currentEmp == null){
            return ResponseEntity.notFound().build();
        }
        currentEmp.setEmployeeNumber(currentEmp.getEmployeeNumber());
        currentEmp.setFirstName(currentEmp.getEmployeeNumber());
        currentEmp.setLastName(currentEmp.getEmployeeNumber());
        currentEmp.setFullName(currentEmp.getEmployeeNumber());
        currentEmp.setTitle(currentEmp.getEmployeeNumber());
        employeesRepository.save(currentEmp);
        return new ResponseEntity(currentEmp, HttpStatus.OK);
    }
    @RequestMapping(path = "/{customersID}", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity<Customers> updateCar(@PathVariable(name = "customersID", value = "customersID") Integer customersID, @RequestBody Customers customers){
        Customers currentCust = customersRepository.findOne(customersID);
        if (currentCust == null){
            return ResponseEntity.notFound().build();
        }
        currentCust.setRrvLicNumber(customers.getRrvLicNumber());
        currentCust.setFullName(customers.getFullName());
        currentCust.setAddress(customers.getAddress());
        currentCust.setCity(customers.getCity());
        customersRepository.save(currentCust);
        return new ResponseEntity(currentCust, HttpStatus.OK);
    }
    @RequestMapping(path = "/{rentalOrderID}", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity<RentalOrders> updateRent(@PathVariable(name = "rentalOrderID", value = "rentalOrderID") Integer carID, @RequestBody RentalOrders rentalOrders){
        RentalOrders currentRent = rentalOrdersRepository.findOne(carID);
        if (currentRent == null){
            return ResponseEntity.notFound().build();
        }
        currentRent.setEmployees(rentalOrders.getEmployees());
        currentRent.setCars(rentalOrders.getCars());
        currentRent.setCustomers(rentalOrders.getCustomers());
        currentRent.setDays(rentalOrders.getDays());
        currentRent.setOrderStatus(rentalOrders.getOrderStatus());
        currentRent.setCustomers(rentalOrders.getCustomers());
        rentalOrdersRepository.save(currentRent);
        return new ResponseEntity(currentRent, HttpStatus.OK);
    }
}
