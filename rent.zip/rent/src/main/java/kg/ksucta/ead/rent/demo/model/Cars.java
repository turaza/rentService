package kg.ksucta.ead.rent.demo.model;

import javax.persistence.*;

@Entity
@Table(name = "cars")
public class Cars {
    @Id
    @GeneratedValue
    private int CarID;
    @Column
    private String TagNumber;
    @Column
    private String Make;
    @Column
    private String Model;

//    public Cars(String TagNumber, String Make, String Model){
//
//        this.TagNumber = TagNumber;
//        this.Model = Model;
//        this.Make = Make;
//
//    }

    public int getCarID() {
        return CarID;
    }

    public void setCarID(int carID) {
        CarID = carID;
    }

    public String getTagNumber() {
        return TagNumber;
    }

    public void setTagNumber(String tagNumber) {
        TagNumber = tagNumber;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String make) {
        Make = make;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }
}
