package kg.ksucta.ead.rent.demo.repositories;

import kg.ksucta.ead.rent.demo.model.Cars;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CarsRepository extends CrudRepository <Cars, Integer> {
    List<Cars> findAll();

    Cars save(Cars saved);

    void delete(Cars carID);

//    Cars findOne(Cars carID);

}
