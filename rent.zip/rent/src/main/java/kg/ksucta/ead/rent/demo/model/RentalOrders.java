package kg.ksucta.ead.rent.demo.model;

import org.postgresql.util.PGmoney;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "rentalorders")
public class RentalOrders {
    @Id
    @GeneratedValue
    private int RentalOrderID;
    @ManyToOne
    private Employees employees;
    @ManyToOne
    private Customers customers;
    @ManyToOne
    private Cars cars;
    @Column
    private Date RentStartDate;
    @Column
    private Date RentEndDate;
    @Column
    private int Days;
    @Column
    private PGmoney RateApplied;
    @Column
    private String OrderTotal;
    @Column
    private String OrderStatus;

    public RentalOrders(){

    }

    public int getRentalOrderID() {
        return RentalOrderID;
    }

    public void setRentalOrderID(int rentalOrderID) {
        RentalOrderID = rentalOrderID;
    }

    public Employees getEmployees() {
        return employees;
    }

    public void setEmployees(Employees employees) {
        this.employees = employees;
    }

    public Customers getCustomers() {
        return customers;
    }

    public void setCustomers(Customers customers) {
        this.customers = customers;
    }

    public Cars getCars() {
        return cars;
    }

    public void setCars(Cars cars) {
        this.cars = cars;
    }

    public Date getRentStartDate() {
        return RentStartDate;
    }

    public void setRentStartDate(Date rentStartDate) {
        RentStartDate = rentStartDate;
    }

    public Date getRentEndDate() {
        return RentEndDate;
    }

    public void setRentEndDate(Date rentEndDate) {
        RentEndDate = rentEndDate;
    }

    public int getDays() {
        return Days;
    }

    public void setDays(int days) {
        Days = days;
    }

    public PGmoney getRateApplied() {
        return RateApplied;
    }

    public void setRateApplied(PGmoney rateApplied) {
        RateApplied = rateApplied;
    }

    public String getOrderTotal() {
        return OrderTotal;
    }

    public void setOrderTotal(String orderTotal) {
        OrderTotal = orderTotal;
    }

    public String getOrderStatus() {
        return OrderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        OrderStatus = orderStatus;
    }
}
