package kg.ksucta.ead.rent.demo.repositories;

import kg.ksucta.ead.rent.demo.model.RentalOrders;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RentalOrdersRepository extends CrudRepository <RentalOrders, Integer> {
    List<RentalOrders> findAll();

    RentalOrders save(RentalOrders saved);

    void delete(RentalOrders rentalOrdersID);
}
