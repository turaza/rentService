package kg.ksucta.ead.rent.demo.repositories;

import kg.ksucta.ead.rent.demo.model.Employees;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EmployeesRepository extends CrudRepository<Employees, Integer> {
    List<Employees> findAll();

    Employees save(Employees saved);


}
